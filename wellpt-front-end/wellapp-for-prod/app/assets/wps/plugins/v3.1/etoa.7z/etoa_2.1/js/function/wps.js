if (typeof(window.wps) == "undefined") {
    window.wps = window;
}