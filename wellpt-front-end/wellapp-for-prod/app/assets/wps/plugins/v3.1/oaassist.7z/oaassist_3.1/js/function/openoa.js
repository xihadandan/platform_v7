// function OnOpenOAClicked() {
//     wps.OAAssist.ShellExecute("http://wpspro.support.wps.cn/oaassist/demo_js.html");
// }

// ///////////////////////////文档不落地需用925版WPS////////////////////////////////
// function OnOpenOAClickedbk() {
//     // wps.WpsApplication().Documents.OpenFromUrl("http://www.colasoft.com.cn/teaching/application_003.doc");

//     //docx
//     wps.WpsApplication().Documents.OpenFromUrl("http://dev.wpseco.cn/wps-oa/document/getFileData/1130", "OnSuccess", "OnFail");

//     // doc
//     // wps.WpsApplication().Documents.OpenFromUrl("http://dev.wpseco.cn/wps-oa/document/getFileData/437", "OnSuccess", "OnFail");

// }

// function OnSuccess(resp) {
//     alert("下载文档成功");
// }

// function OnFail(resp) {
//     alert("下载文档失败");
// }